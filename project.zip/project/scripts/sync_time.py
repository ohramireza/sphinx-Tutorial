"""
functions.sync_time
-------------------

This script takes care of the synchronisation time.

:copyright: (c) 2021 by Hochschule Bonn Rhein Sieg and the Institute of Terrestrial Infrastructures, German Aerospace Center (DLR)
:license: see LICENSE for more details.
"""
from time import sleep
import pandas as pd

def create_new_time(data, key_value, threshold ,test_drill):
    """This is an example function.
    This function performes the multiplication of an array
    
    Parameters
    ----------
    
    data : arr
        Input array. 
    key_value : str
        Input str. 
    threshold : float
        Input threshold. 
    Test_drill : bol
        Input bol. 
     
    Returns
    -------
    
    data : array
        Resulting array from the operation.
    
    """      
    data_list = data[key_value].tolist()
    flag = True
    offset = 0
    if test_drill:
        k = 10000
    else:
        k = 0
    for i in range(len(data_list)-k):
        n = i +k
        if data_list[n] > threshold and flag:
            offset = n
            flag = False
    new_timeaxis = []
    for i in range(len(data_list)):
        new_timeaxis.append(i-offset)   
    data['time_sync'] = new_timeaxis
    data.set_index('time_sync', inplace=True)
    return data